/*
Pete Nordquist  120413
I tried to creat a variable to hold the path then
concatenate this value to each file name for the
load data local infile command, e.g.,

set @loadPath='P:\\cs360\\lab2\\';
LOAD DATA LOCAL INFILE CONCAT(@loadPath,'Animal.csv')
   INTO TABLE Animal FIELDS TERMINATED BY ',';

Unfortunately, it didn't work, and I see in the the
manual: "The file name must be given as a literal string."
Grrrr.
So, you must replace all occurrences of P:\\cs360\\lab2\\
with the path for your local files.
*/

# Drop existing tables in order
drop table if exists Sale;
drop table if exists Customer;
drop table if exists AnimalOrderItem;
drop table if exists AnimalOrder;
drop table if exists Supplier;
drop table if exists Employee;
drop table if exists City;
drop table if exists Animal;

# Animal table

CREATE  TABLE `Animal` (
  `AnimalID` INT NOT NULL ,
  `Name` VARCHAR(45) NULL ,
  `Category` VARCHAR(45) NULL ,
  `Breed` VARCHAR(45) NULL ,
  `DateBorn` DATE NULL ,
  `Gender` VARCHAR(45) NULL ,
  `Registered` VARCHAR(45) NULL ,
  `Color` VARCHAR(45) NULL ,
  `ListPrice` DECIMAL(6,2) NULL,
  PRIMARY KEY (`AnimalID`) )
  ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\Animal.csv'
    INTO TABLE Animal FIELDS TERMINATED BY ',';

# City

CREATE  TABLE `City` (
  `CityID` INT NOT NULL ,
  `ZipCode` VARCHAR(45) NULL ,
  `City` VARCHAR(45) NULL ,
  `State` VARCHAR(45) NULL ,
  `AreaCode` VARCHAR(45) NULL ,
  `Population1980` INT NULL ,
  `Country` VARCHAR(45) NULL ,
  PRIMARY KEY (`CityID`) )
  ENGINE = InnoDB;


LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\City.csv'
    INTO TABLE City FIELDS TERMINATED BY ',';

# Employee

CREATE  TABLE `Employee` (
  `EmployeeID` INT NOT NULL ,
  `LastName` VARCHAR(45) NULL ,
  `FirstName` VARCHAR(45) NULL ,
  `Phone` VARCHAR(45) NULL ,
  `Address` VARCHAR(45) NULL ,
  `ZipCode` VARCHAR(45) NULL ,
  `CityID` INT NULL ,
  `TaxPayerID` VARCHAR(45) NULL ,
  `DateHired` DATE NULL ,
  `DateReleased` DATE NULL ,
  `ManagerID` INT NULL ,
  `EmployeeLevel` INT NULL ,
  `Title` VARCHAR(45) NULL ,
  PRIMARY KEY (`EmployeeID`),
  CONSTRAINT `empCityFK` FOREIGN KEY (`CityID`) REFERENCES `City` (`CityID`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\Employee.csv'
    INTO TABLE Employee FIELDS TERMINATED BY ',';

# Supplier

CREATE  TABLE `Supplier` (
  `SupplierID` INT NOT NULL ,
  `Name` VARCHAR(45) NULL ,
  `ContactName` VARCHAR(45) NULL ,
  `Phone` VARCHAR(45) NULL ,
  `Address` VARCHAR(45) NULL ,
  `ZipCode` VARCHAR(45) NULL ,
  `CityID` INT NULL ,
  PRIMARY KEY (`SupplierID`),
  CONSTRAINT `supCityFK` FOREIGN KEY (`CityID`) REFERENCES `City` (`CityID`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\Supplier.csv'
    INTO TABLE Supplier FIELDS TERMINATED BY ',';

# AnimalOrder

CREATE  TABLE `AnimalOrder` (
  `OrderID` INT NOT NULL ,
  `OrderDate` DATE NULL ,
  `ReceiveDate` DATE NULL ,
  `SupplierID` INT NULL ,
  `ShippingCost` DECIMAL(6,2) NULL ,
  `EmployeeID` INT NULL ,
  PRIMARY KEY (`OrderID`),
  CONSTRAINT `aoSupplierFK` FOREIGN KEY (`SupplierID`) REFERENCES `Supplier` (`SupplierID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aoEmployeeFK` FOREIGN KEY (`EmployeeID`) REFERENCES `Employee` (`EmployeeID`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\AnimalOrder.csv'
    INTO TABLE AnimalOrder FIELDS TERMINATED BY ',';

# AnimalOrderItem

CREATE  TABLE `AnimalOrderItem` (
  `OrderID` INT NOT NULL ,
  `AnimalID` INT NOT NULL ,
  `Cost` DECIMAL(6,2) NULL ,
  PRIMARY KEY (`OrderID`,`AnimalID`),
  CONSTRAINT `aoiAnimalOrderFK` FOREIGN KEY (`OrderID`) REFERENCES `AnimalOrder` (`OrderID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `aoiAnimalFK` FOREIGN KEY (`AnimalID`) REFERENCES `Animal` (`AnimalID`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\AnimalOrderItem.csv'
    INTO TABLE AnimalOrderItem FIELDS TERMINATED BY ',';

# Customer table

CREATE  TABLE `Customer` (
  `CustomerID` INT NOT NULL ,
  `Phone` VARCHAR(45) NULL ,
  `FirstName` VARCHAR(45) NULL ,
  `LastName` VARCHAR(45) NULL ,
  `Address` VARCHAR(45) NULL ,
  `ZipCode` VARCHAR(45) NULL ,
  `CityID` INT NULL ,
  PRIMARY KEY (`CustomerID`)
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\Customer.csv'
    INTO TABLE Customer FIELDS TERMINATED BY ',';

# Sale

CREATE  TABLE `Sale` (
  `SaleID` INT NOT NULL ,
  `SaleDate` DATE NULL ,
  `EmployeeID` INT NULL ,
  `CustomerID` INT NULL ,
  `SalesTax` DECIMAL(6,2) NULL ,
  PRIMARY KEY (`SaleID`),
  CONSTRAINT `sEmployeeFK` FOREIGN KEY (`EmployeeID`) REFERENCES `Employee` (`EmployeeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sCustomerFK` FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE = InnoDB;

LOAD DATA LOCAL INFILE 'P:\\cs360\\lab2\\Sale.csv'
    INTO TABLE Sale FIELDS TERMINATED BY ',';

